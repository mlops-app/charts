# ITOps Platform

Kubernetes-native IT Operations Platform with service discovery, SLA monitoring, incident management, and GitOps-driven ticketing.

## Quick Start

```bash
helm repo add itops https://charts.mlops.hu
helm install itops itops/itops -n itops --create-namespace \
  --set secretEnv.ITOPS_LICENSE_KEY="<your-license-jwt>"
```

That's it. The chart deploys everything automatically:
- **Core** — Go backend API (GraphQL + REST)
- **UI** — Vue.js admin dashboard
- **Landing** — public marketing + docs site (optional, `landing.enabled`)
- **PostgreSQL** — bundled database

Default login: `admin` / `Password123!` (change after first login).

> The license JWT controls which plugins (Ticketing, SLA) are activated at boot. Without a license the platform runs in base mode (no plugins). Generate dev licenses with the `cmd/license-gen` tool in the core repo.

## Expose Externally

```bash
helm install itops itops/itops -n itops --create-namespace \
  --set ingress.hosts[0].host=api.yourdomain.com \
  --set ingress.tls[0].hosts[0]=api.yourdomain.com \
  --set uiIngress.hosts[0].host=app.yourdomain.com \
  --set uiIngress.tls[0].hosts[0]=app.yourdomain.com
```

Requires an ingress controller (nginx recommended) and cert-manager for TLS.

## Connect Agents

After deploying the platform, install the [ITOps Agent](https://charts.mlops.hu) on each Kubernetes cluster you want to monitor:

```bash
helm install itops-agent itops/itops-agent \
  --set node.id="myorg/platform/prod/cluster1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.value="YOUR_OPERATOR_API_KEY" \
  -n itops --create-namespace
```

The operator key is set in the platform chart under `secretEnv.ITOPS_OPERATOR_API_KEY`.

Non-Kubernetes services (VMs, bare-metal hosts, managed cloud resources) integrate via the authenticated push API at `POST /api/v1/health/report` — no agent required.

## Use External Database

To use your own PostgreSQL instead of the bundled one:

```bash
helm install itops itops/itops -n itops --create-namespace \
  --set postgresql.enabled=false \
  --set env.ITOPS_DATABASE_HOST=my-postgres.default \
  --set secretEnv.ITOPS_DATABASE_PASSWORD=mypassword
```

The platform uses PostgreSQL only — no Redis, no other state stores.

## GitOps Ticketing (Phase A–E refactor)

The Ticketing plugin loads its workflows, service catalog, and on-call groups from `values.yaml` via Helm-rendered ConfigMaps. There is no admin UI for these — edit YAML, `helm upgrade`, done.

```yaml
ticketing:
  org: mlops-app                 # auto-prefix for short names

  groups:
    - name: incident-responders
    - name: change-implementers
    - name: problem-investigators
    - name: provisioners

  workflows:
    - name: incident_response
      transitions:
        - {from: OPEN, to: IN_PROGRESS, role: incident-responders}
        - {from: IN_PROGRESS, to: RESOLVED, role: incident-responders}
        - {from: RESOLVED, to: CLOSED, role: any}

  catalog:
    categories:
      - {name: incidents, displayName: "Incidents", icon: report_problem}
    items:
      - name: outage_report
        category: incidents
        displayName: "Service Outage"
        workflow: incident_response
        defaults: {priority: CRITICAL}
        sla: {responseMinutes: 15, resolutionMinutes: 240}
```

Per-service `it-ops.yaml` files (delivered by the agent) may opt in to auto-incident creation, bind a catalog item template, or declare service-scoped workflows and groups that merge into the registry under the service path prefix.

```yaml
# Inside a service's it-ops.yaml
incidents:
  enabled: true
  catalogItem: outage_report     # auto-ticket inherits its workflow + group

ticketing:                        # optional, service-scoped registry extension
  groups:
    - {name: oncall, users: ["alice"]}
  workflows:
    - name: fast-track
      transitions:
        - {from: OPEN, to: IN_PROGRESS, role: oncall}
```

Group lookup is hierarchical: a `role: oncall` reference is resolved by walking up the service path (org → platform → environment → cluster → service) and picking the most specific match. See [the GitOps setup docs](https://www.mlops.hu/pages/docs/ticketing/gitops-setup.html) for the full flow.

## Configuration

| Parameter | Description | Default |
|---|---|---|
| `core.replicaCount` | Backend API replicas | `1` |
| `ui.replicaCount` | Frontend replicas | `1` |
| `database.host` / `.name` / `.user` | PostgreSQL connection (password in `secretEnv.DATABASE_PASSWORD`) | bundled |
| `redis.enabled` | Bundled Redis (rate limit, revocation, idempotency) | `true` |
| `env.APP_BASE_URL` | Public URL of the dashboard (password-reset links) | `https://app.example.com` |
| `env.HTTP_CORS_ALLOWED_ORIGINS` | The dashboard origin(s) | `https://app.example.com` |
| `secretEnv.ITOPS_LICENSE_KEY` | Ed25519 license JWT (controls active plugins) | _unset → base mode_ |
| `secretEnv.DATABASE_PASSWORD` | Database password | `itops-default-password` |
| `secretEnv.AUTH_JWT_KEYS` | Ed25519 token signing seeds, `kid=base64(32 bytes)` | `change me` |
| `secretEnv.AUTH_CSRF_KEY` | CSRF HMAC key | `change me` |
| `secretEnv.ITOPS_OPERATOR_API_KEY` | Agent / push API key | `change-me-in-production` |
| `secretEnv.ITOPS_BOOTSTRAP_ADMIN_PASSWORD` | First admin password on an empty database | `Password123!` |
| `ingress.hosts[0].host` | API domain | `api.example.com` |
| `uiIngress.hosts[0].host` | Dashboard domain | `app.example.com` |
| `landing.enabled` | Deploy bundled landing/docs site | `false` |
| `postgresql.enabled` | Deploy bundled PostgreSQL | `true` |
| `plugins.ticketing.enabled` | Render the ticketing ConfigMap mount | `true` |
| `plugins.sla.enabled` | Render the SLA plugin wiring | `true` |
| `auth.ldap.enabled` | LDAP/AD login (see `values-auth.yaml`) | `false` |
| `ticketing.org` | Org-prefix for short workflow / group names | _required when plugin active_ |

For all options, see `helm show values itops/itops`.

## Architecture

```
                    ┌─────────────┐
 Users ──────────── │  UI (nginx) │
                    └──────┬──────┘
                           │ GraphQL + WebSocket
                    ┌──────▼──────┐
 Agents ──────────► │  Core (Go)  │
   (per cluster)    └──────┬──────┘
 Push APIs ────────►       │
   (VMs, cloud)     ┌──────▼──────┐
                    │  PostgreSQL │
                    └─────────────┘
```

The optional `landing/` deployment serves the public marketing site at `https://www.mlops.hu` and the documentation; it has no runtime dependency on the core.

## Production Checklist

- [ ] Set `secretEnv.ITOPS_LICENSE_KEY` to a customer-issued license JWT (without it the plugins stay disabled)
- [ ] Set `secretEnv.AUTH_JWT_KEYS` (`echo "k1=$(openssl rand -base64 32)"`) and `AUTH_CSRF_KEY` (`openssl rand -hex 32`)
- [ ] Change `secretEnv.ITOPS_OPERATOR_API_KEY` (generate with `openssl rand -hex 32`)
- [ ] Change `secretEnv.DATABASE_PASSWORD` and `ITOPS_BOOTSTRAP_ADMIN_PASSWORD`
- [ ] Set `env.APP_BASE_URL` and `env.HTTP_CORS_ALLOWED_ORIGINS` to the dashboard URL
- [ ] Configure ingress domains
- [ ] Consider managed PostgreSQL in production (`postgresql.enabled=false`)
- [ ] Review `ticketing.org`, default workflows, and on-call groups before exposing the dashboard

## Links

- Website: [https://www.mlops.hu](https://www.mlops.hu)
- Documentation: [https://www.mlops.hu/pages/docs.html](https://www.mlops.hu/pages/docs.html)
- Helm Charts: [https://charts.mlops.hu](https://charts.mlops.hu)
