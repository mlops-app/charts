# `groups/` — GitOps source for the platform's role groups

This directory holds one YAML file per group. The chart renders them
into a single ConfigMap, mounted into the core pod at `/etc/itops/groups/`.
Symmetric with `ticketing/`: a single source of truth,
version-controlled, reviewable in PRs.

## Layout

```
groups/
├── README.md
├── incident-responders.yaml
├── change-implementers.yaml
├── problem-investigators.yaml
└── provisioners.yaml
```

One file per group — adding or renaming a group is a single-file PR.

## What's active today

The 4 default ITSM groups ship out of the box. They are the targets that
the default workflow `role:` fields reference:

- `incident-responders` — incident triage and mitigation
- `change-implementers` — execute and sign off on planned changes
- `problem-investigators` — root cause analysis
- `provisioners` — request fulfillment (access, software, hardware)

## How they reach the core

There is **one groups system** in the platform — the `groups` DB table
plus the `user_groups` membership table. These YAML files are the
**bootstrap source**: on first install, the rows are created from the
`groups/` ConfigMap; subsequent membership management happens in the UI
Users page or via LDAP sign-in (see `values-auth.yaml`).

> The backend reads this directory (`ITOPS_GROUPS_PATH`, default
> `/etc/itops/groups`) on every start and upserts each group by name —
> a renamed `displayName` follows on the next rollout. The SQL migration
> seeds the same four groups, so a chart without the mount still works.

## Why one file per group

- Adding a group is a single-file PR — no merge conflicts with edits
  on other groups.
- The file name **matches** the group's short name. `helm template`
  output shows `<release>-groups: groups-incident-responders.yaml: |`
  so Kubernetes audit / `kubectl describe` is readable.
- Path-override style names (`prod/c1/db-admins`) live in their own
  files too: `groups/prod-c1-db-admins.yaml` (slashes flattened to
  dashes for the file name; the `name:` field inside keeps the
  hierarchical form).

## What's NOT here

- **User memberships** — those live in the `user_groups` DB table
  (populated by the UI or LDAP sync). YAML-driven user-list bootstrap
  is intentionally out of scope: passwords, MFA, login telemetry are
  runtime data, not chart YAML.
- **LDAP group mapping** — there is no mapping table: an LDAP group
  whose cn equals a platform group name defined here joins the user to
  that group on every login (see `values-auth.yaml`).
