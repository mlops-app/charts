# ITOps Platform

Kubernetes-native IT Operations Platform with service discovery, SLA monitoring, incident management, and ticketing.

## Quick Start

```bash
helm repo add itops https://charts.mlops.hu
helm install itops itops/itops -n itops --create-namespace
```

That's it. The chart deploys everything automatically:
- **Core** - Go backend API (GraphQL + REST)
- **UI** - Vue.js admin dashboard
- **PostgreSQL** - bundled database
- **Redis** - bundled cache & pub/sub

Default login: `admin` / `admin` (change after first login).

## Expose Externally

```bash
helm install itops itops/itops -n itops --create-namespace \
  --set ingress.hosts[0].host=api.yourdomain.com \
  --set ingress.tls[0].hosts[0]=api.yourdomain.com \
  --set uiIngress.hosts[0].host=app.yourdomain.com \
  --set uiIngress.tls[0].hosts[0]=app.yourdomain.com
```

Requires an ingress controller (nginx recommended) and cert-manager for TLS.

## Connect Agents

After deploying the platform, install the [ITOps Agent](https://charts.mlops.hu) on each Kubernetes cluster you want to monitor:

```bash
helm install itops-agent itops/itops-agent \
  --set node.id="myorg/platform/prod/cluster1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.value="YOUR_OPERATOR_API_KEY" \
  -n itops --create-namespace
```

The `OPERATOR_API_KEY` is set in the platform chart under `secretEnv.ITOPS_SECURITY_OPERATOR_API_KEY`.

## Use External Database / Redis

To use your own PostgreSQL and Redis instead of the bundled ones:

```bash
helm install itops itops/itops -n itops --create-namespace \
  --set postgresql.enabled=false \
  --set env.ITOPS_DATABASE_HOST=my-postgres.default \
  --set secretEnv.ITOPS_DATABASE_PASSWORD=mypassword \
  --set redis.enabled=false \
  --set env.ITOPS_REDIS_HOST=my-redis.default
```

## Configuration

| Parameter | Description | Default |
|---|---|---|
| `core.replicaCount` | Backend API replicas | `1` |
| `ui.replicaCount` | Frontend replicas | `1` |
| `env.ITOPS_DATABASE_HOST` | PostgreSQL host | `itops-postgresql` |
| `env.ITOPS_REDIS_HOST` | Redis host | `itops-redis-master` |
| `secretEnv.ITOPS_DATABASE_PASSWORD` | Database password | `itops-default-password` |
| `secretEnv.ITOPS_JWT_SECRET` | JWT signing secret | `change-me-in-production` |
| `secretEnv.ITOPS_SECURITY_OPERATOR_API_KEY` | Agent API key | `change-me-in-production` |
| `ingress.hosts[0].host` | API domain | `api.example.com` |
| `uiIngress.hosts[0].host` | Dashboard domain | `app.example.com` |
| `postgresql.enabled` | Deploy bundled PostgreSQL | `true` |
| `redis.enabled` | Deploy bundled Redis | `true` |
| `env.ITOPS_FEATURE_LOCAL_AUTH` | Username/password login | `true` |
| `env.ITOPS_FEATURE_LDAP_AUTH` | LDAP/AD login | `false` |
| `env.ITOPS_PLUGINS_TICKETING_ENABLED` | Ticketing plugin | `true` |
| `env.ITOPS_PLUGINS_SLA_ENABLED` | SLA monitoring plugin | `true` |

For all options, see `helm show values itops/itops`.

## Architecture

```
                    ┌─────────────┐
 Users ──────────── │  UI (nginx) │
                    └──────┬──────┘
                           │ GraphQL + WebSocket
                    ┌──────▼──────┐
 Agents ──────────► │  Core (Go)  │
   (per cluster)    └──┬──────┬───┘
                       │      │
                ┌──────▼┐  ┌──▼────┐
                │ Postgres│  │ Redis │
                └────────┘  └───────┘
```

## Production Checklist

- [ ] Change `secretEnv.ITOPS_JWT_SECRET` (generate with `openssl rand -hex 32`)
- [ ] Change `secretEnv.ITOPS_SECURITY_OPERATOR_API_KEY` (generate with `openssl rand -hex 32`)
- [ ] Change `secretEnv.ITOPS_DATABASE_PASSWORD`
- [ ] Configure ingress domains
- [ ] Consider using managed PostgreSQL and Redis (`postgresql.enabled=false`, `redis.enabled=false`)
- [ ] Change default admin password after first login

## Links

- Website: [https://www.mlops.hu](https://www.mlops.hu)
- Documentation: [https://www.mlops.hu/pages/docs.html](https://www.mlops.hu/pages/docs.html)
- Helm Charts: [https://charts.mlops.hu](https://charts.mlops.hu)
