# `users/` — GitOps source for identity-provider configuration

This directory holds one YAML file per identity provider. The chart
renders them into a single ConfigMap, mounted into the core pod at
`/etc/itops/users/`. The intent is symmetric with `ticketing/`: a single
source of truth, version-controlled, reviewable in PRs.

## Layout

```
users/
├── README.md
├── ldap.yaml      # active provider (LDAP / Active Directory)
├── m365.yaml      # placeholder — Microsoft 365 / Entra ID, planned
└── aws.yaml       # placeholder — AWS IAM Identity Center, planned
```

## What's active today

- **`ldap.yaml`** — full schema, the core reads it on boot. Companies
  using AD or OpenLDAP fork the chart and edit this file. The
  `groupMappings` array maps LDAP CN values to ITOps groups (the same
  groups managed in the platform's `groups` DB table — see Phase F);
  matching users JIT-provision on first login.

## Placeholders (not wired yet)

- **`m365.yaml`** — Microsoft 365 / Entra ID OAuth provider. The schema
  matches what the core will accept once the provider is implemented.
  Until then, the file exists only as a visual / forking template.
- **`aws.yaml`** — AWS IAM Identity Center (formerly SSO). Same status
  as M365.

## How it relates to the rest of the platform

- **Local auth** stays in `values.yaml` under `auth.local.*` — username /
  password is wired into the core's auth provider manager directly,
  not via this directory.
- **Group memberships** still live in the `groups` and `user_groups` DB
  tables. LDAP `groupMappings` here only describe which CN maps to
  which platform group; the membership rows themselves are populated by
  the LDAP sync, not by chart YAML.
- The legacy `auth.ldap.*` block in `values.yaml` is being retired in
  favour of this directory. During the transition both read paths are
  honoured; once every install ships its LDAP config from `users/`,
  the `values.yaml` block can be removed.
