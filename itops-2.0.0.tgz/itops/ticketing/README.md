# `ticketing/` — GitOps source of truth for the ticketing registry

Everything the Ticketing plugin knows at boot time lives here. The chart
renders the contents of this directory into a single ConfigMap, mounted
into the core pod at `/etc/itops/ticketing/`. The core reads every
`*.yaml` file and merges them in lexicographic order.

There is **no admin UI** for these files. To change anything, edit YAML,
`helm upgrade`, and the next core boot picks up the new registry.

## Layout

```
ticketing/
├── org.yaml                         # the auto-prefix applied to every short name
├── groups.yaml                      # ITSM role groups (incident-responders, …)
├── workflows/
│   ├── incident-response.yaml       # 1 file = 1 workflow (reviewable in PRs)
│   ├── major-incident.yaml
│   ├── service-request.yaml
│   ├── change-request.yaml
│   ├── emergency-change.yaml
│   ├── problem-investigation.yaml
│   └── access-request.yaml
└── catalog/
    ├── incidents.yaml               # 1 file = 1 category + its items
    ├── requests.yaml
    ├── changes.yaml
    ├── problems.yaml
    └── access.yaml
```

## What ships out of the box

- **7 workflows** — the ITIL 4 four pillars (incident, request, change,
  problem) plus access management, with `major_incident` and
  `emergency_change` as separate workflows for audit / SLA reasons.
- **4 role groups** — `incident-responders`, `change-implementers`,
  `problem-investigators`, `provisioners`. Descriptive role names rather
  than organisation-specific team names so the workflows stay portable.
- **5 catalog categories, 25 items** — covers the ~80% volume of a typical
  service desk: outages, password resets, hardware requests, access
  requests, certificate renewals, onboarding / offboarding, etc.

Each item has industry-benchmark SLA defaults (response and resolution
times) and an optional `featured: true` marker that pins the most-used
items to the top of the New Ticket dialog.

## Customising

Customisation is by **chart fork**, not by `values.yaml` overrides. The
`values.yaml` deliberately has no `ticketing:` section so there is one
single source of truth for the registry.

To customise:

```bash
helm pull itops/itops --untar              # extract the chart
cd itops/ticketing/                      # edit YAML files here
# add a new workflow
cat > workflows/security-incident.yaml <<'YAML'
workflows:
  - name: security_incident
    displayName: "Security Incident"
    transitions:
      - {from: OPEN,        to: IN_PROGRESS, role: incident-responders}
      - {from: IN_PROGRESS, to: RESOLVED,    role: incident-responders}
      - {from: RESOLVED,    to: CLOSED,      role: incident-responders}
YAML
helm upgrade itops .                       # install from the local chart
```

For GitOps deployments, fork this chart into your own Git repository and
keep `ticketing/` under version control there.

## File semantics

- Every file is parsed as a partial `File` struct with these top-level
  keys: `org`, `groups`, `workflows`, `catalog.{categories,items}`.
- The merger appends `workflows`, `groups`, `catalog.categories`, and
  `catalog.items` lists across all files.
- `org` is taken from the first file that declares it (lexicographic
  order). Keep `org.yaml` as the only file with this field to avoid
  surprises.
- Names are unique within their type. If two files declare workflows
  with the same `name`, the second one overrides the first — but treat
  this as an accident, not a feature.

## What's NOT in here (and why)

- **`major-outage`-specific runbooks**: too organisation-specific for a
  default. Add your own as a `change_request` (planned) or a
  `problem_investigation` (post-incident) item if you want them
  surfaced in the catalog.
- **CSIRT / security-incident workflows**: companies running serious
  security operations have their own response process. The default
  `incident_response` workflow is suitable for routine security
  events; bespoke flows belong in your fork.
- **Multi-stage CAB approval**: the default `change_request` workflow
  treats CAB review as a comment / status note. If your audit regime
  requires a discrete approval state, define your own workflow with an
  extra transition (e.g. `OPEN → AWAITING_APPROVAL → IN_PROGRESS`).
