# ITOps Agent

Kubernetes operator that connects your cluster to the ITOps platform. It discovers services, monitors their health, and reports SLA metrics automatically.

## Quick Start

```bash
helm repo add itops https://charts.mlops.hu
helm install itops-agent itops/itops-agent \
  --set node.id="myorg/platform/prod/cluster1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.value="YOUR_API_KEY" \
  -n itops --create-namespace
```

You need 3 things:

| Parameter | Where to find it |
|---|---|
| `node.id` | ITOps UI > Settings > Clusters, or create your own: `org/platform/env/cluster` |
| `itops.url` | Your ITOps API endpoint (e.g. `https://api.yourdomain.com`) |
| `itops.apiKey.value` | ITOps UI > Settings > API Keys, or the `ITOPS_SECURITY_OPERATOR_API_KEY` from the platform chart |

## Same-Cluster Setup

If the ITOps platform runs in the same cluster, use the internal service URL:

```bash
helm install itops-agent itops/itops-agent \
  --set node.id="myorg/platform/prod/cluster1" \
  --set itops.url="http://itops-core.itops:8080" \
  --set itops.apiKey.value="YOUR_API_KEY" \
  -n itops
```

## How It Works

1. The agent watches Kubernetes namespaces for Deployments, StatefulSets, and DaemonSets
2. Services with an `it-ops.yaml` ConfigMap are automatically discovered
3. Health status is reported to the ITOps platform every 30 seconds
4. SLA groups are synced based on the `slaGroup` field in each service's config

```
Your K8s Cluster                    ITOps Platform
┌──────────────────┐                ┌──────────────┐
│  ITOps Agent     │───status───►   │  Core API    │
│  - watches pods  │   every 30s    │  - SLA calc  │
│  - reads configs │◄──expected──   │  - ticketing │
│  - reports health│   every 60s    │  - dashboard │
└──────────────────┘                └──────────────┘
```

## Service Discovery

Add an `it-ops.yaml` ConfigMap to your service's Helm chart:

```yaml
# my-service/templates/configmap-itops.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: my-service-itops
  labels:
    itops.io/config: "true"
data:
  it-ops.yaml: |
    version: "1"
    service:
      criticality: "high"
      slaGroup: "payment-system"
      type: "api"
      team: "backend"
      displayName: "Payment API"
      description: "Handles payment processing"
```

Or add it to your `values.yaml`:

```yaml
# my-service/values.yaml
itops:
  criticality: "high"
  slaGroup: "payment-system"
  type: "api"
  team: "backend"
```

## Configuration

| Parameter | Description | Default |
|---|---|---|
| `node.id` | **Required.** Cluster hierarchy ID | `""` |
| `itops.url` | **Required.** ITOps API URL | `""` |
| `itops.apiKey.value` | **Required.** API key (plain text) | `""` |
| `itops.apiKey.existingSecret` | Use K8s Secret instead | `""` |
| `watch.namespaces` | Namespaces to monitor | `["default"]` |
| `watch.excludeNamespaces` | Namespaces to skip | `["kube-system", ...]` |
| `features.autoRegister` | Auto-register discovered services | `true` |
| `features.autoCreateIncidents` | Auto-create incidents for DOWN services | `false` |
| `sync.statusInterval` | How often to push status | `30s` |
| `sync.fullSyncInterval` | Full sync interval | `5m` |
| `slaGroups` | SLA group definitions | `[]` |
| `log.level` | Log verbosity | `info` |
| `environment.type` | Environment detection | `auto` |

For all options, see `helm show values itops/itops-agent`.

## SLA Groups

Define SLA groups in the agent chart and assign services to them via `slaGroup` in their `it-ops.yaml`:

```yaml
# In the agent values.yaml
slaGroups:
  - name: "payment-system"
    displayName: "Payment System"
    tier: "critical"
    targets:
      uptime: 99.99
      responseTime: 5
      resolutionTime: 60

  - name: "web-frontend"
    displayName: "Web Frontend"
    tier: "high"
```

Available tiers: `critical`, `high`, `medium`, `low`.

## API Key via Kubernetes Secret (Production)

For production, store the API key in a K8s Secret instead of plain text:

```bash
kubectl create secret generic itops-api-key \
  --from-literal=api-key=YOUR_KEY \
  -n itops

helm install itops-agent itops/itops-agent \
  --set node.id="myorg/platform/prod/cluster1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.existingSecret="itops-api-key" \
  -n itops
```

## Multi-Cluster Setup

Deploy one agent per cluster, each with a unique `node.id`:

```bash
# Production cluster
helm install itops-agent itops/itops-agent \
  --set node.id="acme/itops/prod/eu-west-1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.value="KEY" \
  -n itops --create-namespace

# Staging cluster
helm install itops-agent itops/itops-agent \
  --set node.id="acme/itops/staging/eu-west-1" \
  --set itops.url="https://api.yourdomain.com" \
  --set itops.apiKey.value="KEY" \
  -n itops --create-namespace
```

All clusters report to the same ITOps platform and appear in the dashboard.

## Links

- Website: [https://www.mlops.hu](https://www.mlops.hu)
- Documentation: [https://www.mlops.hu/pages/docs.html](https://www.mlops.hu/pages/docs.html)
- Platform Chart: [https://charts.mlops.hu](https://charts.mlops.hu)
